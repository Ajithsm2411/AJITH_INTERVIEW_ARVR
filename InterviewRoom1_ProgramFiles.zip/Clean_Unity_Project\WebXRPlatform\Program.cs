using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Collections.Concurrent;

var builder = WebApplication.CreateBuilder(args);

// Configure port
builder.WebHost.UseUrls("http://0.0.0.0:5000", "http://localhost:5000");

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseWebSockets(new WebSocketOptions
{
    KeepAliveInterval = TimeSpan.FromSeconds(20)
});

// Real-Time Interview Session Room Manager
var roomSessions = new ConcurrentDictionary<string, InterviewSessionRoom>();

app.Map("/ws/interview", async context =>
{
    if (context.WebSockets.IsWebSocketRequest)
    {
        string roomId = context.Request.Query["room"].FirstOrDefault() ?? "interview-room-1";
        string role = context.Request.Query["role"].FirstOrDefault() ?? "interviewer";
        string participantId = Guid.NewGuid().ToString("N")[..8];

        using var webSocket = await context.WebSockets.AcceptWebSocketAsync();
        var room = roomSessions.GetOrAdd(roomId, id => new InterviewSessionRoom(id));
        var participant = new Participant(participantId, role, webSocket);
        
        await room.JoinAsync(participant);
    }
    else
    {
        context.Response.StatusCode = StatusCodes.Status400BadRequest;
    }
});

// REST API for session status & diagnostics
app.MapGet("/api/status", () =>
{
    var stats = roomSessions.Select(kv => new
    {
        RoomId = kv.Key,
        Participants = kv.Value.GetParticipantSummaries(),
        CreatedAt = kv.Value.CreatedAt
    });

    return Results.Json(new
    {
        status = "online",
        platform = "WebXR Spatial Interview Telepresence Platform",
        totalActiveRooms = roomSessions.Count,
        rooms = stats
    });
});

app.Run();

// -------------------------------------------------------------
// Session Management & Real-Time Synchronization Models
// -------------------------------------------------------------
public class Participant
{
    public string Id { get; }
    public string Role { get; set; }
    public WebSocket Socket { get; }
    public DateTime ConnectedAt { get; } = DateTime.UtcNow;

    public Participant(string id, string role, WebSocket socket)
    {
        Id = id;
        Role = role;
        Socket = socket;
    }
}

public class InterviewSessionRoom
{
    public string RoomId { get; }
    public DateTime CreatedAt { get; } = DateTime.UtcNow;
    private readonly ConcurrentDictionary<string, Participant> _participants = new();

    public InterviewSessionRoom(string roomId)
    {
        RoomId = roomId;
    }

    public async Task JoinAsync(Participant participant)
    {
        _participants[participant.Id] = participant;

        // Welcome message with assigned role and room state
        var welcomeMsg = JsonSerializer.Serialize(new
        {
            type = "welcome",
            participantId = participant.Id,
            role = participant.Role,
            roomId = RoomId,
            peerCount = _participants.Count - 1,
            peers = GetParticipantSummaries()
        });

        await SendTextAsync(participant.Socket, welcomeMsg);

        // Notify other peers in this session
        var joinNotification = JsonSerializer.Serialize(new
        {
            type = "peer_joined",
            participantId = participant.Id,
            role = participant.Role,
            totalCount = _participants.Count
        });
        await BroadcastExceptAsync(participant.Id, joinNotification);

        // Receive loop
        var buffer = new byte[1024 * 32];
        try
        {
            while (participant.Socket.State == WebSocketState.Open)
            {
                var result = await participant.Socket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                if (result.MessageType == WebSocketMessageType.Close)
                {
                    break;
                }
                else if (result.MessageType == WebSocketMessageType.Text)
                {
                    var msgJson = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    // Broadcast participant tracking state, voice sync, or role switch to room
                    await BroadcastExceptAsync(participant.Id, msgJson);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Room {RoomId}] Participant {participant.Id} error: {ex.Message}");
        }
        finally
        {
            _participants.TryRemove(participant.Id, out _);
            var leaveNotification = JsonSerializer.Serialize(new
            {
                type = "peer_left",
                participantId = participant.Id,
                role = participant.Role,
                totalCount = _participants.Count
            });
            await BroadcastAllAsync(leaveNotification);

            try
            {
                if (participant.Socket.State == WebSocketState.Open)
                {
                    await participant.Socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Session closed", CancellationToken.None);
                }
            }
            catch { }
        }
    }

    public IEnumerable<object> GetParticipantSummaries()
    {
        return _participants.Values.Select(p => new
        {
            id = p.Id,
            role = p.Role,
            connectedAt = p.ConnectedAt
        });
    }

    private async Task BroadcastExceptAsync(string excludeParticipantId, string message)
    {
        var bytes = Encoding.UTF8.GetBytes(message);
        var segment = new ArraySegment<byte>(bytes);

        foreach (var p in _participants.Values)
        {
            if (p.Id != excludeParticipantId && p.Socket.State == WebSocketState.Open)
            {
                try
                {
                    await p.Socket.SendAsync(segment, WebSocketMessageType.Text, true, CancellationToken.None);
                }
                catch { }
            }
        }
    }

    private async Task BroadcastAllAsync(string message)
    {
        var bytes = Encoding.UTF8.GetBytes(message);
        var segment = new ArraySegment<byte>(bytes);

        foreach (var p in _participants.Values)
        {
            if (p.Socket.State == WebSocketState.Open)
            {
                try
                {
                    await p.Socket.SendAsync(segment, WebSocketMessageType.Text, true, CancellationToken.None);
                }
                catch { }
            }
        }
    }

    private static async Task SendTextAsync(WebSocket socket, string message)
    {
        if (socket.State == WebSocketState.Open)
        {
            var bytes = Encoding.UTF8.GetBytes(message);
            await socket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
        }
    }
}
