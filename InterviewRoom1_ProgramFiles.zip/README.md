# Interview Room Program Files & Clean Project Archive

This separate directory contains all the program files, source code, scripts, project configurations, and a clean standalone Unity project archive created from `c:\InterviewRoom1`.

---

## Directory Structure

```text
Exported_ProgramFiles/
├── Source_Scripts_And_Code/
│   ├── Scripts/                     <-- Core Runtime C# Scripts
│   │   ├── VR/                      <-- Seated VR Headset Rig & Spatial UI
│   │   │   ├── VRGogglesRig.cs
│   │   │   ├── VRControllerPointer.cs
│   │   │   └── VRSpatialVirtualScreen.cs
│   │   ├── SpeechToText/            <-- Voice Transcription & 3D Avatar Bubbles
│   │   │   ├── SpeechToTextTranscriptionController.cs
│   │   │   └── AvatarSpeechBubble3D.cs
│   │   ├── InterviewRoomController.cs        <-- Main Dialogue & Voice Interview Loop
│   │   ├── InterviewRoomAudioController.cs   <-- VR Microphone Recording & Playback
│   │   ├── AvatarAnimationController.cs      <-- Candidate & Interviewer Gestures / Lip-Sync
│   │   ├── InterviewRoomRuntimeBootstrap.cs  <-- Scene & Seated Camera Initializer
│   │   ├── HologramEffect.cs                 <-- Visual Hologram Shader/FX
│   │   └── FreeFlyCamera.cs                  <-- Desktop Debug Camera
│   ├── Editor/                      <-- Unity Editor Automation & Wizards
│   │   ├── InterviewRoomBuilder.cs  <-- One-Click Scene Construction & Setup
│   │   └── MetaQuest3SetupWizard.cs <-- Meta Quest 3 & OpenXR Manifest Wizard
│   ├── WebXRPlatform/               <-- Standalone .NET WebXR Server & Frontend
│   │   ├── Program.cs
│   │   ├── WebXRInterviewRoom.csproj
│   │   ├── appsettings.json
│   │   └── wwwroot/ (HTML5, CSS, Three.js WebXR engine)
│   ├── InterviewRoom1.sln           <-- Visual Studio Solution File
│   ├── Assembly-CSharp.csproj       <-- C# Project File (Runtime)
│   ├── Assembly-CSharp-Editor.csproj<-- C# Project File (Editor)
│   ├── InputSystem_Actions.inputactions
│   └── .vsconfig
│
└── Clean_Unity_Project/             <-- Clean Standalone Unity Project (~10.5 MB)
    ├── Assets/                      <-- All Assets, Materials, Prefabs, Scenes, Scripts
    ├── Packages/                    <-- Unity Package Manifests & Dependencies
    ├── ProjectSettings/             <-- Input, Quality, Tags, Layers, XR Settings
    ├── WebXRPlatform/               <-- WebXR Server
    ├── InterviewRoom1.sln
    └── Assembly-CSharp.csproj
```

---

## Key Program Files & Their Functions

1. **`VRGogglesRig.cs`** ([Assets/Scripts/VR/VRGogglesRig.cs](file:///c:/InterviewRoom1/Assets/Scripts/VR/VRGogglesRig.cs))
   - Implements the seated eye-level VR headset experience anchored to character chairs ($1.20\text{m}$ eye height).
   - Culls head/neck bones so the user looks down and sees their seated body without internal skull mesh clipping.

2. **`InterviewRoomController.cs`** ([Assets/Scripts/InterviewRoomController.cs](file:///c:/InterviewRoom1/Assets/Scripts/InterviewRoomController.cs))
   - Automated interview dialogue flow:
     - Interviewer (Dr. Vance) generates and asks the question.
     - Candidate records user's voice answer through the VR headset microphone.
     - Candidate character (Alex Mercer) responds to the interviewer with voice playback, speech bubbles, and conversational gestures.
     - Interviewer evaluates and advances to the next question.

3. **`InterviewRoomAudioController.cs`** ([Assets/Scripts/InterviewRoomAudioController.cs](file:///c:/InterviewRoom1/Assets/Scripts/InterviewRoomAudioController.cs))
   - Handles VR headset microphone recording, clip creation, real-time waveform level analysis, and 3D spatial playback.

4. **`AvatarAnimationController.cs`** ([Assets/Scripts/AvatarAnimationController.cs](file:///c:/InterviewRoom1/Assets/Scripts/AvatarAnimationController.cs))
   - Procedural conversational animation, lip-sync jaw flutter driven by voice audio, idle breathing, and emotional reactions.

5. **`InterviewRoomRuntimeBootstrap.cs`** ([Assets/Scripts/InterviewRoomRuntimeBootstrap.cs](file:///c:/InterviewRoom1/Assets/Scripts/InterviewRoomRuntimeBootstrap.cs))
   - Bootstraps the scene at runtime, verifies character seating, builds the VR rig, and kicks off the automated interview.

6. **`InterviewRoomBuilder.cs`** ([Assets/Editor/InterviewRoomBuilder.cs](file:///c:/InterviewRoom1/Assets/Editor/InterviewRoomBuilder.cs))
   - Editor tool to assemble the conference room, characters, lighting, UI canvas, and VR rigs in the scene with one click.
